var App = (function(){
	
	
	return{
		
	init: function(){
		
		
	}	
		
	}
	
})();
