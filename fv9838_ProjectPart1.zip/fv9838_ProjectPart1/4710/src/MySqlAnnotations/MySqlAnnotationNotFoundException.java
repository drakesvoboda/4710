package MySqlAnnotations;

public class MySqlAnnotationNotFoundException extends Exception{

	private static final long serialVersionUID = 1L;

	public MySqlAnnotationNotFoundException(String message){		
		super(message);
	}
}
